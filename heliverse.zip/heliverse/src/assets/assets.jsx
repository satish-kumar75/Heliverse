import img1 from "./motionarteffect-img1.png";
import img2 from "./motionarteffect-img2.png";
import img3 from "./motionarteffect-img3.png";
import img4 from "./motionarteffect-img4.png";
import img5 from "./motionarteffect-img5.png";
import img6 from "./motionarteffect-img6.png";
import img7 from "./motionarteffect-img7.png";
import img8 from "./motionarteffect-img8.png";
import img9 from "./motionarteffect-img9.png";
import img10 from "./motionarteffect-img10.png";
import img11 from "./motionarteffect-img11.png";
import logo from "./MotionArtEffect-logo.png";

export const assets = {
  img1,
  img2,
  img3,
  img4,
  img5,
  img6,
  img7,
  img8,
  img9,
  img10,
  img11,
  logo,
};
